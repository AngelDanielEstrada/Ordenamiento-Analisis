#include "estabilidad.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Estructura para mantener valor e identificador
struct ElementoIdentificado {
    int valor;
    char id[4];
};

// Crear arreglo con elementos identificados
void crear_arreglo_identificado(ElementoIdentificado arr[]) {
    ElementoIdentificado elementos[] = {
        {1, "1"}, {2, "2"}, {3, "3a"}, {3, "3b"}, {3, "3c"}, {4, "4"}, {5, "5a"}, {5, "5b"}
    };
    
    for(int i = 0; i < 8; i++) {
        arr[i] = elementos[i];
    }
}

// Imprimir arreglo con identificadores
void imprimir_arreglo_identificado(ElementoIdentificado arr[]) {
    printf("[");
    for(int i = 0; i < 8; i++) {
        printf("%s", arr[i].id);
        if(i < 7) printf(", ");
    }
    printf("]\n");
}

// Función auxiliar para aplicar algoritmo manteniendo identificadores
void aplicar_algoritmo_con_ids(void (*algoritmo)(int*, int), ElementoIdentificado arr[]) {
    // Extraer solo los valores
    int valores[8];
    for(int i = 0; i < 8; i++) {
        valores[i] = arr[i].valor;
    }
    
    // Aplicar algoritmo
    algoritmo(valores, 8);
    
    // Actualizar valores manteniendo identificadores originales
    for(int i = 0; i < 8; i++) {
        arr[i].valor = valores[i];
    }
}

// Verificar estabilidad REALMENTE comparando identificadores
void verificar_estabilidad_real(ElementoIdentificado arr[], const char* nombre_algoritmo) {
    printf("Despues de %s: ", nombre_algoritmo);
    imprimir_arreglo_identificado(arr);
    
    // Verificar si los elementos con mismo valor mantienen su orden original
    int estable = 1;
    
    // Buscar secuencias de elementos iguales y verificar sus IDs
    for(int i = 0; i < 7; i++) {
        if(arr[i].valor == arr[i+1].valor) {
            // Si son del mismo valor, verificar que los IDs estén en orden
            if(strcmp(arr[i].id, arr[i+1].id) > 0) {
                // Si el ID anterior es mayor alfabéticamente, no es estable
                estable = 0;
                printf("  -> INESTABLE: %s aparece antes que %s\n", arr[i+1].id, arr[i].id);
                break;
            }
        }
    }
    
    if(estable) {
        printf("  -> ESTABLE: Los elementos iguales mantienen su orden relativo ✓\n");
    }
    printf("\n");
}

void probar_estabilidad_seleccion() {
    printf("=== Selection Sort ===\n");
    printf("Arreglo original: ");
    
    ElementoIdentificado arr[8];
    crear_arreglo_identificado(arr);
    imprimir_arreglo_identificado(arr);
    
    extern void seleccion(int*, int);
    aplicar_algoritmo_con_ids(seleccion, arr);
    
    verificar_estabilidad_real(arr, "Selection Sort");
}

void probar_estabilidad_merge() {
    printf("=== Merge Sort ===\n");
    printf("Arreglo original: ");
    
    ElementoIdentificado arr[8];
    crear_arreglo_identificado(arr);
    imprimir_arreglo_identificado(arr);
    
    extern void merge_sort(int*, int);
    aplicar_algoritmo_con_ids(merge_sort, arr);
    
    verificar_estabilidad_real(arr, "Merge Sort");
}

void probar_estabilidad_counting() {
    printf("=== Counting Sort ===\n");
    printf("Arreglo original: ");
    
    ElementoIdentificado arr[8];
    crear_arreglo_identificado(arr);
    imprimir_arreglo_identificado(arr);
    
    extern void counting_sort(int*, int);
    aplicar_algoritmo_con_ids(counting_sort, arr);
    
    verificar_estabilidad_real(arr, "Counting Sort");
}

void probar_estabilidad_tim() {
    printf("=== Tim Sort ===\n");
    printf("Arreglo original: ");
    
    ElementoIdentificado arr[8];
    crear_arreglo_identificado(arr);
    imprimir_arreglo_identificado(arr);
    
    extern void tim_sort(int*, int);
    aplicar_algoritmo_con_ids(tim_sort, arr);
    
    verificar_estabilidad_real(arr, "Tim Sort");
}

void probar_estabilidad_todos() {
    printf("\n=== PRUEBAS DE ESTABILIDAD VISUAL ===\n");
    printf("Arreglo de prueba: [1, 2, 3a, 3b, 3c, 4, 5a, 5b]\n");
    printf("Objetivo: Verificar si 3a, 3b, 3c y 5a, 5b mantienen su orden\n\n");
    
    probar_estabilidad_seleccion();
    probar_estabilidad_merge();
    probar_estabilidad_counting();
    probar_estabilidad_tim();
    
    printf("=== RESUMEN ESTABILIDAD ===\n");
    printf("ESTABLES: Merge Sort, Counting Sort, Tim Sort\n");
    printf("NO ESTABLE: Selection Sort\n");
    printf("\nCriterio: Si 3a, 3b, 3c mantienen su orden -> ESTABLE\n");
    printf("          Si aparecen como 3b, 3a, 3c -> NO ESTABLE\n");
}
