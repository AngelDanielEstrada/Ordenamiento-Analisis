#ifndef ESTABILIDAD_H
#define ESTABILIDAD_H

// SOLO declarar la estructura aquí
typedef struct ElementoIdentificado ElementoIdentificado;

void probar_estabilidad_seleccion();
void probar_estabilidad_merge();
void probar_estabilidad_counting();
void probar_estabilidad_tim();
void probar_estabilidad_todos();

#endif
