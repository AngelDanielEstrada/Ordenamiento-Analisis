#include "metodos.h"

// ======================================================
// ================== SELECTION SORT =====================
// ======================================================
void selectionSort(int arr[], int n, Metricas* metricas) {
    resetearMetricas(metricas);
    clock_t inicio = clock();
    
    for (int i = 0; i < n - 1; i++) {
        int min_idx = i;
        
        for (int j = i + 1; j < n; j++) {
            metricas->comparaciones++;
            if (arr[j] < arr[min_idx]) min_idx = j;
        }
        if (min_idx != i) {
            int temp = arr[min_idx];
            arr[min_idx] = arr[i];
            arr[i] = temp;
            metricas->swaps++;
        }
    }
    
    metricas->tiempo_ms =
        ((double)(clock() - inicio) * 1000.0) / CLOCKS_PER_SEC;
    calcularEstabilidad(metricas, "selection");
}

// ======================================================
// ==================== MERGE SORT =======================
// ======================================================
static void merge(int arr[], int l, int m, int r, Metricas* metricas) {
    int n1 = m - l + 1, n2 = r - m;
    
    int* L = malloc(n1 * sizeof(int));
    int* R = malloc(n2 * sizeof(int));

    for (int i = 0; i < n1; i++) L[i] = arr[l + i];
    for (int j = 0; j < n2; j++) R[j] = arr[m + 1 + j];
    
    int i = 0, j = 0, k = l;
    
    while (i < n1 && j < n2) {
        metricas->comparaciones++;
        if (L[i] <= R[j]) arr[k++] = L[i++];
        else arr[k++] = R[j++];
        metricas->swaps++;
    }
    while (i < n1) arr[k++] = L[i++], metricas->swaps++;
    while (j < n2) arr[k++] = R[j++], metricas->swaps++;

    free(L); free(R);
}

static void mergeSortRec(int arr[], int l, int r, Metricas* metricas) {
    if (l < r) {
        int m = l + (r - l)/2;
        mergeSortRec(arr, l, m, metricas);
        mergeSortRec(arr, m+1, r, metricas);
        merge(arr, l, m, r, metricas);
    }
}

void mergeSortWrapper(int arr[], int n, Metricas* metricas) {
    resetearMetricas(metricas);
    clock_t inicio = clock();
    
    mergeSortRec(arr, 0, n - 1, metricas);
    
    metricas->tiempo_ms =
        ((double)(clock() - inicio) * 1000.0) / CLOCKS_PER_SEC;
    calcularEstabilidad(metricas, "merge");
}

// ======================================================
// ================== COUNTING SORT ======================
// ======================================================
void countingSort(int arr[], int n, Metricas* metricas) {
    resetearMetricas(metricas);
    clock_t inicio = clock();
    
    int min = arr[0], max = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] < min) min = arr[i];
        if (arr[i] > max) max = arr[i];
    }
    
    int range = max - min + 1;
    int* count = calloc(range, sizeof(int));
    int* output = malloc(n * sizeof(int));

    for (int i = 0; i < n; i++)
        count[arr[i] - min]++;

    for (int i = 1; i < range; i++)
        count[i] += count[i - 1];

    for (int i = n - 1; i >= 0; i--) {
        output[count[arr[i] - min] - 1] = arr[i];
        count[arr[i] - min]--;
        metricas->swaps++;
    }

    for (int i = 0; i < n; i++)
        arr[i] = output[i], metricas->swaps++;

    free(count);
    free(output);

    metricas->tiempo_ms =
        ((double)(clock() - inicio) * 1000.0) / CLOCKS_PER_SEC;
    calcularEstabilidad(metricas, "counting");
}

// ======================================================
// ===================== TIM SORT ========================
// ======================================================
const int RUN = 32;

static void insertionSortTim(int arr[], int left, int right, Metricas* metricas) {
    for (int i = left + 1; i <= right; i++) {
        int temp = arr[i], j = i - 1;

        while (j >= left && arr[j] > temp) {
            arr[j + 1] = arr[j];
            j--;
            metricas->comparaciones++;
            metricas->swaps++;
        }
        arr[j + 1] = temp;
        metricas->swaps++;
    }
}

void timSort(int arr[], int n, Metricas* metricas) {
    resetearMetricas(metricas);
    clock_t inicio = clock();
    
    for (int i = 0; i < n; i += RUN) {
        int right = (i + RUN - 1 < n ? i + RUN - 1 : n - 1);
        insertionSortTim(arr, i, right, metricas);
    }
    
    for (int size = RUN; size < n; size *= 2) {
        for (int left = 0; left < n; left += 2 * size) {
            int mid = left + size - 1;
            int right = (left + 2 * size - 1 < n ? left + 2 * size - 1 : n - 1);
            if (mid < right) merge(arr, left, mid, right, metricas);
        }
    }
    
    metricas->tiempo_ms =
        ((double)(clock() - inicio) * 1000.0) / CLOCKS_PER_SEC;
    calcularEstabilidad(metricas, "tim");
}

// ======================================================
// ================ FUNCIONES NECESARIAS =================
// ======================================================
void resetearMetricas(Metricas* m) {
    m->tiempo_ms = 0;
    m->comparaciones = 0;
    m->swaps = 0;
    m->estable = 1;
}

void calcularEstabilidad(Metricas* m, const char* alg) {
    if (strcmp(alg, "selection") == 0) m->estable = 0;
    strcpy(m->estable_str, m->estable ? "SI" : "NO");
}

// ----------------- Generación de arreglos -----------------

int rand_r(unsigned int *seed) {
    *seed = *seed * 1103515245 + 12345;
    return (*seed / 65536) % 32768;
}

static int* generarUniforme(int n) {
    int* arr = malloc(n * sizeof(int));
    unsigned int seed = time(NULL);

    for (int i = 0; i < n; i++)
        arr[i] = rand_r(&seed) % 100;

    return arr;
}

static int* generarOrdenado(int n) {
    int* arr = malloc(n * sizeof(int));
    for (int i = 0; i < n; i++) arr[i] = i;
    return arr;
}

static int* generarReverso(int n) {
    int* arr = malloc(n * sizeof(int));
    for (int i = 0; i < n; i++) arr[i] = n - 1 - i;
    return arr;
}

static int* generarCasi(int n) {
    int* arr = generarOrdenado(n);
    unsigned int seed = time(NULL);

    for (int i = 0; i < n / 10; i++) {
        int a = rand_r(&seed) % n;
        int b = rand_r(&seed) % n;
        int t = arr[a]; arr[a] = arr[b]; arr[b] = t;
    }
    return arr;
}

static int* generarDuplicados(int n) {
    int* arr = malloc(n * sizeof(int));
    int vals[] = {1,2,3,5,8,13,21};
    unsigned int seed = time(NULL);

    for (int i = 0; i < n; i++)
        arr[i] = vals[rand_r(&seed) % 7];

    return arr;
}

int* generarArreglo(int n, const char* tipo) {
    if (!strcmp(tipo,"uniform")) return generarUniforme(n);
    if (!strcmp(tipo,"ordenado")) return generarOrdenado(n);
    if (!strcmp(tipo,"reverso")) return generarReverso(n);
    if (!strcmp(tipo,"casi")) return generarCasi(n);
    if (!strcmp(tipo,"duplicados")) return generarDuplicados(n);
    return generarUniforme(n);
}

void copiarArreglo(int o[], int d[], int n) {
    for (int i = 0; i < n; i++) d[i] = o[i];
}

void verificarOrdenado(int arr[], int n, int* ok) {
    *ok = 1;
    for (int i = 0; i < n-1; i++)
        if (arr[i] > arr[i+1]) { *ok = 0; break; }
}

void guardarResultadoCSV(Resultado r[], int n) {
    FILE* f = fopen("resultados.csv","w");
    if (!f) return;

    fprintf(f,"algoritmo,tamaño,distribucion,tiempo_ms,comparaciones,swaps,estable\n");

    for (int i=0;i<n;i++)
        fprintf(f,"%s,%d,%s,%.6f,%ld,%ld,%s\n",
                r[i].algoritmo, r[i].tamaño, r[i].distribucion,
                r[i].metrics.tiempo_ms, r[i].metrics.comparaciones,
                r[i].metrics.swaps, r[i].metrics.estable_str);

    fclose(f);
}

