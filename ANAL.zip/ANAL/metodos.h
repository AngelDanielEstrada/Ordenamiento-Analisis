#ifndef METODOS_H
#define METODOS_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

// ======== Estructuras ========

typedef struct {
    double tiempo_ms;
    long comparaciones;
    long swaps;
    int estable;
    char estable_str[3];
} Metricas;

typedef struct {
    char algoritmo[20];
    int tamaño;
    char distribucion[15];
    Metricas metrics;
} Resultado;

// ======== Funciones de ordenamiento ========

void selectionSort(int arr[], int n, Metricas* metricas);
void mergeSortWrapper(int arr[], int n, Metricas* metricas);
void countingSort(int arr[], int n, Metricas* metricas);
void timSort(int arr[], int n, Metricas* metricas);

// ======== Auxiliares necesarias ========

void resetearMetricas(Metricas* metricas);
void calcularEstabilidad(Metricas* metricas, const char* algoritmo);
int* generarArreglo(int n, const char* tipo);
void copiarArreglo(int origen[], int destino[], int n);
void verificarOrdenado(int arr[], int n, int* ordenado);
void guardarResultadoCSV(Resultado resultados[], int count);

// rand_r (solo esta, porque sí se usa)
int rand_r(unsigned int *seed);

#endif

