#!/usr/bin/env python3
import pandas as pd
import matplotlib.pyplot as plt
import os
import sys
import numpy as np

def abrir_imagen(archivo):
    if sys.platform == "win32":
        os.startfile(archivo)
    elif sys.platform == "darwin":
        os.system(f"open {archivo}")
    else:
        os.system(f"xdg-open {archivo}")

df = pd.read_csv('resultados.csv')
print("Leyendo resultados.csv...")
print(f"Total de registros: {len(df)}")
print(f"Algoritmos: {', '.join(df['algoritmo'].unique())}")

grouped = df.groupby(['algoritmo', 'tamaño']).agg({
    'tiempo_ms': 'mean',
    'comparaciones': 'mean', 
    'swaps': 'mean'
}).reset_index()

tiempos_max = grouped.groupby('algoritmo')['tiempo_ms'].max()
ratio_max_min = tiempos_max.max() / tiempos_max.min()
print(f"Ratio máximo/mínimo de tiempos: {ratio_max_min:.1f}")

usar_escala_log = ratio_max_min > 100

colores = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']
algoritmos = sorted(df['algoritmo'].unique())
markers = ['o', 's', '^', 'D', 'v']

print("Generando gráficas de tiempos...")
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

for i, algoritmo in enumerate(algoritmos):
    datos_algo = grouped[grouped['algoritmo'] == algoritmo]
    ax1.plot(datos_algo['tamaño'], datos_algo['tiempo_ms'], 
             marker=markers[i], linewidth=2, markersize=6,
             label=algoritmo, color=colores[i], alpha=0.8)
    ax2.plot(datos_algo['tamaño'], datos_algo['tiempo_ms'],
             marker=markers[i], linewidth=2, markersize=6,
             label=algoritmo, color=colores[i], alpha=0.8)

ax1.set_xlabel('Tamaño del Arreglo')
ax1.set_ylabel('Tiempo (ms)')
ax1.set_title('Tiempos de Ejecución (Escala Lineal)')
ax1.legend()
ax1.grid(True, alpha=0.3)

ax2.set_xlabel('Tamaño del Arreglo')
ax2.set_ylabel('Tiempo (ms)')
ax2.set_title('Tiempos de Ejecución (Escala Logarítmica)')
ax2.set_yscale('log')
ax2.legend()
ax2.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('tiempos_comparacion.png', dpi=150, bbox_inches='tight')
plt.close()

print("Generando gráficas de comparaciones...")
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

algoritmos_con_comparaciones = [algo for algo in algoritmos 
                               if not grouped[grouped['algoritmo'] == algo]['comparaciones'].isna().all()]

for i, algoritmo in enumerate(algoritmos_con_comparaciones):
    datos_algo = grouped[grouped['algoritmo'] == algoritmo]
    ax1.plot(datos_algo['tamaño'], datos_algo['comparaciones'],
             marker=markers[i], linewidth=2, markersize=6,
             label=algoritmo, color=colores[i], alpha=0.8)
    ax2.plot(datos_algo['tamaño'], datos_algo['comparaciones'],
             marker=markers[i], linewidth=2, markersize=6,
             label=algoritmo, color=colores[i], alpha=0.8)

ax1.set_xlabel('Tamaño del Arreglo')
ax1.set_ylabel('Número de Comparaciones')
ax1.set_title('Comparaciones (Escala Lineal)')
ax1.legend()
ax1.grid(True, alpha=0.3)

ax2.set_xlabel('Tamaño del Arreglo') 
ax2.set_ylabel('Número de Comparaciones')
ax2.set_title('Comparaciones (Escala Logarítmica)')
ax2.set_yscale('log')
ax2.legend()
ax2.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('comparaciones.png', dpi=150, bbox_inches='tight')
plt.close()

print("Generando gráficas individuales...")
fig, axes = plt.subplots(2, 2, figsize=(15, 10))
axes = axes.flatten()

for i, algoritmo in enumerate(algoritmos):
    if i < len(axes):
        datos_algo = grouped[grouped['algoritmo'] == algoritmo]
        axes[i].plot(datos_algo['tamaño'], datos_algo['tiempo_ms'],
                    marker='o', linewidth=2, markersize=5,
                    color=colores[i], alpha=0.8)
        axes[i].set_xlabel('Tamaño del Arreglo')
        axes[i].set_ylabel('Tiempo (ms)')
        axes[i].set_title(f'Tiempos - {algoritmo}')
        axes[i].grid(True, alpha=0.3)

for i in range(len(algoritmos), len(axes)):
    axes[i].set_visible(False)

plt.tight_layout()
plt.savefig('tiempos_individuales.png', dpi=150, bbox_inches='tight')
plt.close()

print("Generando heatmap...")
heatmap_data = grouped.pivot_table(index='algoritmo', columns='tamaño', values='tiempo_ms')
tiempos_minimos = heatmap_data.min()
speedup_relativo = heatmap_data.div(tiempos_minimos)

plt.figure(figsize=(12, 6))
im = plt.imshow(speedup_relativo.values, cmap='RdYlGn_r', aspect='auto', interpolation='nearest')

plt.colorbar(im, label='Factor de Lentitud (vs. el más rápido)')
plt.xticks(range(len(speedup_relativo.columns)), speedup_relativo.columns, rotation=45)
plt.yticks(range(len(speedup_relativo.index)), speedup_relativo.index)
plt.xlabel('Tamaño del Arreglo')
plt.ylabel('Algoritmo')
plt.title('Rendimiento Relativo (1.0 = El más rápido para ese tamaño)')

for i in range(len(speedup_relativo.index)):
    for j in range(len(speedup_relativo.columns)):
        valor = speedup_relativo.iloc[i, j]
        color = 'white' if valor > 2 else 'black'
        plt.text(j, i, f'{valor:.1f}x', ha='center', va='center', color=color, fontweight='bold')

plt.tight_layout()
plt.savefig('heatmap_rendimiento.png', dpi=150, bbox_inches='tight')
plt.close()

print("Generando zoom en algoritmos rápidos...")
plt.figure(figsize=(12, 8))

tiempos_promedio = grouped.groupby('algoritmo')['tiempo_ms'].mean()
algoritmos_rapidos = tiempos_promedio.nsmallest(2).index

for i, algoritmo in enumerate(algoritmos):
    datos_algo = grouped[grouped['algoritmo'] == algoritmo]
    if algoritmo in algoritmos_rapidos:
        plt.plot(datos_algo['tamaño'], datos_algo['tiempo_ms'],
                marker=markers[i], linewidth=3, markersize=8,
                label=f'{algoritmo} (RAPIDO)', color=colores[i], alpha=0.9)
    else:
        plt.plot(datos_algo['tamaño'], datos_algo['tiempo_ms'],
                marker=markers[i], linewidth=1, markersize=4,
                label=algoritmo, color=colores[i], alpha=0.5)

plt.xlabel('Tamaño del Arreglo')
plt.ylabel('Tiempo (ms)')
plt.title('Comparación con Destacado de Algoritmos Rápidos')
plt.legend()
plt.grid(True, alpha=0.3)
plt.savefig('zoom_rapidos.png', dpi=150, bbox_inches='tight')
plt.close()

print("\nGRAFICAS GENERADAS:")
print("  tiempos_comparacion.png - Comparación general (lineal + log)")
print("  comparaciones.png - Análisis de comparaciones (lineal + log)")
print("  tiempos_individuales.png - Detalle por algoritmo")
print("  heatmap_rendimiento.png - Rendimiento relativo")
print("  zoom_rapidos.png - Enfoque en algoritmos más rápidos")

print(f"\nANALISIS DE RESULTADOS:")
print(f"  Usar escala logaritmica: {'SI' if usar_escala_log else 'NO'} (ratio: {ratio_max_min:.1f})")

mejor_por_tamaño = grouped.loc[grouped.groupby('tamaño')['tiempo_ms'].idxmin()]
print(f"\nMEJOR ALGORITMO POR TAMAÑO:")
for _, row in mejor_por_tamaño.iterrows():
    print(f"  Tamaño {row['tamaño']}: {row['algoritmo']} ({row['tiempo_ms']:.2f} ms)")

print("\nAbriendo gráficas...")
graficas = ['tiempos_comparacion.png', 'comparaciones.png', 'heatmap_rendimiento.png']
for img in graficas:
    abrir_imagen(img)

print("\nPROCESO COMPLETADO")
print("Si los algoritmos lentos ocultan a los rápidos, revisa zoom_rapidos.png")
