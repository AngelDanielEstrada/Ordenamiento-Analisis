#include "metodos.h"
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>

// =====================================================
//  PROTOTIPOS DE FUNCIONES AUXILIARES
// =====================================================

void imprimirConfiguracion(int tamaños[], int num_tamaños,
                           const char* distribuciones[], int num_distribuciones,
                           int repeticiones);

void ejecutarBenchmarks(int tamaños[], int num_tamaños,
                        const char* distribuciones[], int num_distribuciones,
                        int repeticiones,
                        Resultado* resultados, int* contador_resultados);


// =====================================================
//  FUNCIÓN PROBAR ALGORITMO (sin cambios)
// =====================================================

void probarAlgoritmo(int arr_original[], int n, const char* nombre_algoritmo, 
                     const char* distribucion, void (*algoritmo)(int[], int, Metricas*),
                     Resultado* resultado) {
    
    int* copia = (int*)malloc(n * sizeof(int));
    copiarArreglo(arr_original, copia, n);
    
    Metricas metricas;
    algoritmo(copia, n, &metricas);
    
    // Verificar ordenamiento
    int ordenado;
    verificarOrdenado(copia, n, &ordenado);
    
    if (!ordenado) {
        printf(" ERROR: %s no ordenó correctamente\n", nombre_algoritmo);
    }
    
    // Guardar resultados
    strcpy(resultado->algoritmo, nombre_algoritmo);
    resultado->tamaño = n;
    strcpy(resultado->distribucion, distribucion);
    resultado->metrics = metricas;
    
    // Imprimir resultados
    printf("  %-12s | %7.3f ms | %10ld | %8ld | %4s | %s\n",
           nombre_algoritmo,
           metricas.tiempo_ms,
           metricas.comparaciones,
           metricas.swaps,
           metricas.estable_str,
           ordenado ? " OK" : " ERROR");
    
    free(copia);
}


// =====================================================
//  FUNCIONES AUXILIARES
// =====================================================

void imprimirConfiguracion(int tamaños[], int num_tamaños,
                           const char* distribuciones[], int num_distribuciones,
                           int repeticiones) {

    printf(" Tamaños: ");
    for (int i = 0; i < num_tamaños; i++)
        printf("%d ", tamaños[i]);

    printf("\n Distribuciones: ");
    for (int i = 0; i < num_distribuciones; i++)
        printf("%s ", distribuciones[i]);

    printf("\n Repeticiones: %d\n\n", repeticiones);
}



void ejecutarBenchmarks(int tamaños[], int num_tamaños,
                        const char* distribuciones[], int num_distribuciones,
                        int repeticiones,
                        Resultado* resultados, int* contador_resultados) {
    
    for (int t = 0; t < num_tamaños; t++) {
        int n = tamaños[t];
        
        for (int d = 0; d < num_distribuciones; d++) {
            const char* dist = distribuciones[d];
            
            for (int r = 0; r < repeticiones; r++) {

                printf("\n Tamaño: %d, Distribución: %s, Repetición: %d\n",
                       n, dist, r + 1);
                printf("---------------------------------------------------\n");
                
                int* arreglo_original = generarArreglo(n, dist);
                
                probarAlgoritmo(arreglo_original, n, "Selection", dist, selectionSort,
                                &resultados[(*contador_resultados)++]);

                probarAlgoritmo(arreglo_original, n, "Merge", dist, mergeSortWrapper,
                                &resultados[(*contador_resultados)++]);

                probarAlgoritmo(arreglo_original, n, "Counting", dist, countingSort,
                                &resultados[(*contador_resultados)++]);

                probarAlgoritmo(arreglo_original, n, "TimSort", dist, timSort,
                                &resultados[(*contador_resultados)++]);
                
                free(arreglo_original);
            }
        }
    }
}



// =====================================================
//  MAIN LIMPIO
// =====================================================

int main() {
    // Semilla aleatoria
    unsigned int semilla = (unsigned int)time(NULL);
    srand(semilla);

    printf(" SEMILLA ALEATORIA: %u\n", semilla);
    printf("=== BENCHMARK ALGORITMOS DE ORDENAMIENTO ===\n");

    // Configuración del experimento
    int tamaños[] = {100, 200, 300, 400, 500, 1000, 2500, 5000, 7500};
    int num_tamaños = sizeof(tamaños) / sizeof(tamaños[0]);

    const char* distribuciones[] = {"uniform", "ordenado", "reverso", "casi", "duplicados"};
    int num_distribuciones = sizeof(distribuciones) / sizeof(distribuciones[0]);

    const int repeticiones = 3;

    // Calcular cuántos resultados se necesitarán
    int max_resultados = num_tamaños * num_distribuciones * 4 * repeticiones;
    Resultado* resultados = (Resultado*)malloc(max_resultados * sizeof(Resultado));
    int contador_resultados = 0;

    // Mostrar parámetros de las pruebas
    imprimirConfiguracion(tamaños, num_tamaños, distribuciones, num_distribuciones, repeticiones);

    printf("ALGORITMO      | TIEMPO   | COMPARACION | SWAPS   | ESTABLE | ESTADO\n");
    printf("---------------|----------|-------------|---------|---------|--------\n");

    // Ejecutar pruebas
    ejecutarBenchmarks(tamaños, num_tamaños,
                       distribuciones, num_distribuciones,
                       repeticiones,
                       resultados, &contador_resultados);

    // Guardar resultados en CSV
    guardarResultadoCSV(resultados, contador_resultados);

    free(resultados);

    printf("\n BENCHMARK COMPLETADO ===\n");
    printf(" Total de pruebas: %d\n", contador_resultados);
    printf(" Archivo 'resultados.csv' generado\n");
    printf(" Ejecuta 'make graphs' para generar gráficas\n");

    return 0;
}

